export default function Header () {
    return (
        <header>
            <h1><center>My Color Picker Project</center></h1>
            <hr />
        </header>
    )
}