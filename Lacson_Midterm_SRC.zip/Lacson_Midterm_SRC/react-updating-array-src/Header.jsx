export default function Header () {
    return (
        <>
        <header>
            <h1><center>This is my list of favorite games</center></h1>
            <hr />
        </header>
        </>
    )    
}