export default function Header () {
    return (
        <header>
            <h1><center>My Quotes Generator</center></h1>
            <hr />
        </header>
    )
}