export default function Footer () {
    return (
        <>
        <footer>
            <hr />
            <p>&copy; {new Date().getFullYear()} My Counter Website || Written by: Carrene Kyla M. Lacson</p>
        </footer>
        </>
    )    
}