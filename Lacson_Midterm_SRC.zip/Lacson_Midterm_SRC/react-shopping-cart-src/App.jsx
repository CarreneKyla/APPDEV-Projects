import { useState } from 'react';
import Login from './Login';
import './App.css';

function App() {
  return (
    <>
      <Login />
    </>
  );
}

export default App;
