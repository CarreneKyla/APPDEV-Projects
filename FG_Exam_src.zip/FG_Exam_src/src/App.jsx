import React from 'react';
import Keyboard from './Keyboard';


function App() {
  return (
    <div className="App">
      <h1>Carrene's Keyboard Showcase</h1>
      <Keyboard />
    </div>
  );
}

export default App;
