export default function Home() {
    return (
      <>
        <h1>Welcome to the Game Showcase</h1>
        <p>Explore my list of exciting games and their reviews.</p>
      </>
    )
  }
  