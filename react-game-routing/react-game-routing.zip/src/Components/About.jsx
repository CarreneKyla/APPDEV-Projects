export default function About() {
    return (
      <>
        <h1>About the Game Showcase</h1>
        <p>This application showcases popular games and their reviews, built using React with React Router for navigation.</p>
      </>
    )
  }
  