const reviews = [
  { id: 1, reviewer: 'Alice', feedback: 'The keyboards are phenomenal!' },
  { id: 2, reviewer: 'Bob', feedback: 'I love the design and functionality.' },
  { id: 3, reviewer: 'Catherine', feedback: 'Top-notch build quality and great customer support.' },
];

export default reviews;
