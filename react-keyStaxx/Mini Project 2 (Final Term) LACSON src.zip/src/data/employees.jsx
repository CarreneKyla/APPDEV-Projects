const employees = [
  { id: 1, name: 'Carrene Kyla M. Lacson', position: 'CEO', qualifications: 'M.S. in Computer Science' },
  { id: 2, name: 'Jane Smith', position: 'Software Developer', qualifications: 'M.S. in Computer Science' },
  { id: 3, name: 'Emma Johnson', position: 'Marketing Specialist', qualifications: 'B.A. in Marketing' },
  { id: 4, name: 'Erckiel Cazel P. Olores', position: 'Front-End Developer', qualifications: 'M.S. in Computer Science' },
  { id: 5, name: 'Miguel T. Ohara', position: 'Marketing Specialist', qualifications: 'B.A. in Marketing' },
  { id: 6, name: 'Nuka O. Taisha', position: 'Front-End Developer', qualifications: 'M.S. in Computer Science' },
];

export default employees;
